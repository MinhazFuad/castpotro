import { TEAM_MEMBERS, CATEGORIES } from './teamData.js';
import { ParticleNetwork } from './particles.js';
import { sounds } from './soundEffects.js';

class TeamApp {
  constructor() {
    this.members = [...TEAM_MEMBERS];
    this.filteredMembers = [...TEAM_MEMBERS];
    this.currentCategory = 'all';
    this.searchQuery = '';
    this.currentView = 'grid'; // 'grid' | 'coverflow' | 'list'
    this.coverflowIndex = 0;
    this.favorites = this.loadFavorites();
    this.activeModalMember = null;
    this.audioEnabled = true;

    this.init();
  }

  init() {
    // 1. Initialize Particles
    new ParticleNetwork('particle-canvas');

    // 2. Render Categories & Stats
    this.renderCategoryTabs();
    this.renderStats();

    // 3. Render Cards based on default view
    this.render();

    // 4. Attach Event Listeners
    this.setupEventListeners();

    // 5. Initialize Lucide Icons
    if (window.lucide) {
      window.lucide.createIcons();
    }
  }

  loadFavorites() {
    try {
      return JSON.parse(localStorage.getItem('castpotro_team_favs')) || [];
    } catch (e) {
      return [];
    }
  }

  saveFavorites() {
    try {
      localStorage.setItem('castpotro_team_favs', JSON.stringify(this.favorites));
    } catch (e) {}
  }

  toggleFavorite(id, e) {
    if (e) e.stopPropagation();
    sounds.playClick();
    if (this.favorites.includes(id)) {
      this.favorites = this.favorites.filter(favId => favId !== id);
      this.showToast("Removed from favorites", "info");
    } else {
      this.favorites.push(id);
      this.triggerSparkles(e ? e.target : null);
      this.showToast("Added to favorites ❤️", "success");
    }
    this.saveFavorites();
    this.render();
  }

  renderStats() {
    const totalCount = this.members.length;
    const countries = new Set(this.members.map(m => m.country)).size;
    const departments = new Set(this.members.map(m => m.category)).size;

    this.animateCounter('stat-members', totalCount);
    this.animateCounter('stat-countries', countries);
    this.animateCounter('stat-departments', departments);
  }

  animateCounter(elementId, target) {
    const el = document.getElementById(elementId);
    if (!el) return;
    let count = 0;
    const duration = 1200;
    const stepTime = Math.abs(Math.floor(duration / target));
    const timer = setInterval(() => {
      count++;
      el.textContent = count;
      if (count >= target) {
        clearInterval(timer);
        el.textContent = target;
      }
    }, stepTime || 50);
  }

  renderCategoryTabs() {
    const container = document.getElementById('category-tabs');
    if (!container) return;

    container.innerHTML = CATEGORIES.map(cat => {
      const count = cat.id === 'all' 
        ? this.members.length 
        : this.members.filter(m => m.category === cat.id).length;

      if (count === 0 && cat.id !== 'all') return '';

      const isActive = this.currentCategory === cat.id;

      return `
        <button 
          data-category="${cat.id}"
          class="filter-tab px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 flex items-center gap-2 glass-panel border ${isActive ? 'active' : 'text-gray-400 hover:text-white border-white/5 hover:border-white/20'}"
        >
          <i data-lucide="${cat.icon}" class="w-4 h-4"></i>
          <span>${cat.label}</span>
          <span class="text-xs px-2 py-0.5 rounded-full ${isActive ? 'bg-white/20 text-white' : 'bg-gray-800 text-gray-400'}">${count}</span>
        </button>
      `;
    }).join('');

    container.querySelectorAll('.filter-tab').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const cat = btn.getAttribute('data-category');
        sounds.playClick();
        this.setCategory(cat);
      });
      btn.addEventListener('mouseenter', () => sounds.playHover());
    });

    if (window.lucide) window.lucide.createIcons();
  }

  setCategory(category) {
    this.currentCategory = category;
    this.renderCategoryTabs();
    this.filterMembers();
  }

  filterMembers() {
    const query = this.searchQuery.toLowerCase().trim();

    this.filteredMembers = this.members.filter(member => {
      const matchCat = this.currentCategory === 'all' || member.category === this.currentCategory;
      const matchSearch = !query || 
        member.name.toLowerCase().includes(query) ||
        member.designation.toLowerCase().includes(query) ||
        member.country.toLowerCase().includes(query) ||
        (member.city && member.city.toLowerCase().includes(query)) ||
        (member.university && member.university.toLowerCase().includes(query)) ||
        (member.skills && member.skills.some(s => s.toLowerCase().includes(query)));

      return matchCat && matchSearch;
    });

    this.coverflowIndex = 0;
    this.render();
  }

  render() {
    const gridContainer = document.getElementById('grid-view-container');
    const coverflowContainer = document.getElementById('coverflow-view-container');
    const listContainer = document.getElementById('list-view-container');
    const emptyState = document.getElementById('empty-state');
    const resultsCount = document.getElementById('results-count');

    if (resultsCount) {
      resultsCount.textContent = `Showing ${this.filteredMembers.length} ${this.filteredMembers.length === 1 ? 'member' : 'members'}`;
    }

    if (this.filteredMembers.length === 0) {
      if (gridContainer) gridContainer.classList.add('hidden');
      if (coverflowContainer) coverflowContainer.classList.add('hidden');
      if (listContainer) listContainer.classList.add('hidden');
      if (emptyState) emptyState.classList.remove('hidden');
      return;
    } else {
      if (emptyState) emptyState.classList.add('hidden');
    }

    if (this.currentView === 'grid') {
      if (gridContainer) gridContainer.classList.remove('hidden');
      if (coverflowContainer) coverflowContainer.classList.add('hidden');
      if (listContainer) listContainer.classList.add('hidden');
      this.renderGrid(gridContainer);
    } else if (this.currentView === 'coverflow') {
      if (gridContainer) gridContainer.classList.add('hidden');
      if (coverflowContainer) coverflowContainer.classList.remove('hidden');
      if (listContainer) listContainer.classList.add('hidden');
      this.renderCoverflow(coverflowContainer);
    } else {
      if (gridContainer) gridContainer.classList.add('hidden');
      if (coverflowContainer) coverflowContainer.classList.add('hidden');
      if (listContainer) listContainer.classList.remove('hidden');
      this.renderList(listContainer);
    }

    if (window.lucide) window.lucide.createIcons();
  }

  renderGrid(container) {
    if (!container) return;

    container.innerHTML = this.filteredMembers.map((member, index) => {
      const isFav = this.favorites.includes(member.id);

      return `
        <div class="team-card-wrapper" data-index="${index}">
          <div class="team-card p-6 flex flex-col justify-between h-full group" data-member-id="${member.id}">
            
            <!-- Card Header -->
            <div>
              <div class="flex items-start justify-between mb-4">
                <span class="text-xs uppercase tracking-wider font-semibold px-3 py-1 rounded-full bg-gradient-to-r ${member.badgeColor} text-white shadow-lg shadow-black/40">
                  ${member.tag}
                </span>

                <button 
                  class="favorite-btn p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-pink-400 transition-colors"
                  data-fav-id="${member.id}"
                  title="${isFav ? 'Remove Favorite' : 'Save Favorite'}"
                >
                  <i data-lucide="heart" class="w-4 h-4 ${isFav ? 'fill-pink-500 text-pink-500' : ''}"></i>
                </button>
              </div>

              <!-- Avatar & Status -->
              <div class="flex flex-col items-center text-center my-3">
                <div class="relative mb-4 group-hover:scale-105 transition-transform duration-500">
                  <div class="avatar-ring">
                    <img 
                      src="${member.imageUrl}" 
                      alt="${member.name}" 
                      onerror="this.src='https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&h=300&fit=crop'"
                      class="w-28 h-28 object-cover rounded-full bg-gray-900 border-2 border-gray-950"
                    />
                  </div>
                  <span class="absolute bottom-1 right-2 w-4 h-4 rounded-full bg-emerald-500 border-2 border-gray-900 status-beacon" title="Active"></span>
                </div>

                <h3 class="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors flex items-center gap-1.5">
                  ${member.name}
                  <span class="text-base" title="${member.country}">${member.countryFlag}</span>
                </h3>
                <p class="text-sm font-medium text-amber-400/90 mt-1">${member.designation}</p>
                <p class="text-xs text-gray-400 mt-0.5 flex items-center gap-1">
                  <i data-lucide="map-pin" class="w-3.5 h-3.5 text-gray-500"></i>
                  ${member.city ? `${member.city}, ` : ''}${member.country}
                </p>
              </div>

              <!-- University / Alma Mater -->
              ${member.university ? `
                <div class="my-3 px-3 py-2 rounded-lg bg-black/20 border border-white/5 flex items-center gap-2">
                  <i data-lucide="graduation-cap" class="w-4 h-4 text-cyan-400 shrink-0"></i>
                  <span class="text-xs text-gray-300 truncate" title="${member.university}">${member.university}</span>
                </div>
              ` : ''}

              <!-- Skills Tags -->
              <div class="flex flex-wrap gap-1.5 my-3">
                ${member.skills.slice(0, 3).map(skill => `
                  <span class="text-[11px] px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-gray-300">${skill}</span>
                `).join('')}
                ${member.skills.length > 3 ? `<span class="text-[11px] px-1.5 py-0.5 rounded-md bg-white/5 text-gray-400">+${member.skills.length - 3}</span>` : ''}
              </div>
            </div>

            <!-- Card Footer & Actions -->
            <div class="mt-4 pt-4 border-t border-white/5 flex items-center justify-between gap-2">
              <div class="flex items-center gap-1.5">
                ${member.socialLinks.linkedin ? `
                  <a 
                    href="${member.socialLinks.linkedin}" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    class="p-2 rounded-lg bg-white/5 hover:bg-[#0A66C2]/20 hover:text-[#0A66C2] text-gray-400 transition-all hover:scale-110"
                    title="LinkedIn Profile"
                  >
                    <i data-lucide="linkedin" class="w-4 h-4"></i>
                  </a>
                ` : ''}

                ${member.socialLinks.instagram ? `
                  <a 
                    href="${member.socialLinks.instagram}" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    class="p-2 rounded-lg bg-white/5 hover:bg-pink-500/20 hover:text-pink-400 text-gray-400 transition-all hover:scale-110"
                    title="Instagram Profile"
                  >
                    <i data-lucide="instagram" class="w-4 h-4"></i>
                  </a>
                ` : ''}

                <button 
                  class="copy-email-btn p-2 rounded-lg bg-white/5 hover:bg-amber-500/20 hover:text-amber-300 text-gray-400 transition-all hover:scale-110"
                  data-email="${member.email}"
                  title="Copy Email"
                >
                  <i data-lucide="mail" class="w-4 h-4"></i>
                </button>
              </div>

              <button 
                class="view-profile-btn text-xs font-semibold px-3 py-2 rounded-xl bg-gradient-to-r from-blue-500/20 to-purple-500/20 hover:from-blue-500 hover:to-purple-600 text-cyan-300 hover:text-white border border-blue-500/30 hover:border-transparent transition-all duration-300 flex items-center gap-1.5 group/btn"
                data-member-id="${member.id}"
              >
                <span>Portfolio</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform"></i>
              </button>
            </div>

          </div>
        </div>
      `;
    }).join('');

    // Attach 3D Card Tilt Effects
    this.attachCardTilt();
    this.attachCardEvents(container);
  }

  attachCardTilt() {
    const cards = document.querySelectorAll('.team-card');
    cards.forEach(card => {
      let bounds;

      function rotateToMouse(e) {
        bounds = card.getBoundingClientRect();
        const mouseX = e.clientX;
        const mouseY = e.clientY;
        const leftX = mouseX - bounds.x;
        const topY = mouseY - bounds.y;
        const center = {
          x: leftX - bounds.width / 2,
          y: topY - bounds.height / 2
        };

        const distance = Math.sqrt(center.x ** 2 + center.y ** 2);
        
        card.style.transform = `
          perspective(1000px)
          rotate3d(
            ${-center.y / 100},
            ${center.x / 100},
            0,
            ${Math.log(distance + 1) * 2.2}deg
          )
          translateZ(8px)
        `;
      }

      card.addEventListener('mouseenter', () => {
        sounds.playHover();
        document.addEventListener('mousemove', rotateToMouse);
      });

      card.addEventListener('mouseleave', () => {
        document.removeEventListener('mousemove', rotateToMouse);
        card.style.transform = '';
      });
    });
  }

  renderCoverflow(container) {
    if (!container) return;

    const items = this.filteredMembers;
    const curIdx = this.coverflowIndex;

    const html = `
      <div class="flex flex-col items-center justify-center w-full py-6">
        <div class="coverflow-container relative flex items-center justify-center">
          ${items.map((member, i) => {
            const diff = i - curIdx;
            let posAttr = '0';

            if (diff === 0) posAttr = '0';
            else if (diff === 1) posAttr = '1';
            else if (diff === -1) posAttr = '-1';
            else if (diff === 2) posAttr = '2';
            else if (diff === -2) posAttr = '-2';
            else if (diff > 2) posAttr = 'hidden-right';
            else posAttr = 'hidden-left';

            return `
              <div 
                class="coverflow-card p-6 rounded-2xl glass-panel border border-white/10 flex flex-col justify-between"
                data-pos="${posAttr}"
                data-index="${i}"
                data-member-id="${member.id}"
              >
                <div class="text-center">
                  <div class="avatar-ring mx-auto mb-4">
                    <img 
                      src="${member.imageUrl}" 
                      alt="${member.name}" 
                      class="w-32 h-32 object-cover rounded-full bg-gray-900 border-2 border-gray-950"
                    />
                  </div>
                  <h3 class="text-xl font-bold text-white flex items-center justify-center gap-1.5">
                    ${member.name}
                    <span>${member.countryFlag}</span>
                  </h3>
                  <p class="text-sm font-semibold text-amber-400 mt-1">${member.designation}</p>
                  <p class="text-xs text-gray-400 mt-1">${member.city ? `${member.city}, ` : ''}${member.country}</p>
                </div>

                <div class="my-4 text-center">
                  <p class="text-xs text-gray-300 line-clamp-3 italic">"${member.quote}"</p>
                </div>

                <button 
                  class="view-profile-btn w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20"
                  data-member-id="${member.id}"
                >
                  <i data-lucide="user" class="w-4 h-4"></i>
                  <span>View Full Profile</span>
                </button>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Coverflow Navigation Controls -->
        <div class="flex items-center gap-4 mt-8">
          <button id="coverflow-prev" class="p-3 rounded-full glass-panel hover:bg-white/20 text-white transition-all hover:scale-110">
            <i data-lucide="chevron-left" class="w-5 h-5"></i>
          </button>
          <span class="text-sm font-mono text-gray-400">${curIdx + 1} / ${items.length}</span>
          <button id="coverflow-next" class="p-3 rounded-full glass-panel hover:bg-white/20 text-white transition-all hover:scale-110">
            <i data-lucide="chevron-right" class="w-5 h-5"></i>
          </button>
        </div>
      </div>
    `;

    container.innerHTML = html;

    // Attach click events on coverflow cards
    container.querySelectorAll('.coverflow-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.view-profile-btn')) return;
        const targetIndex = parseInt(card.getAttribute('data-index'));
        if (targetIndex !== this.coverflowIndex) {
          sounds.playClick();
          this.coverflowIndex = targetIndex;
          this.render();
        }
      });
    });

    const prevBtn = document.getElementById('coverflow-prev');
    const nextBtn = document.getElementById('coverflow-next');

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        sounds.playClick();
        this.coverflowIndex = (this.coverflowIndex - 1 + items.length) % items.length;
        this.render();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        sounds.playClick();
        this.coverflowIndex = (this.coverflowIndex + 1) % items.length;
        this.render();
      });
    }

    this.attachCardEvents(container);
  }

  renderList(container) {
    if (!container) return;

    container.innerHTML = `
      <div class="glass-panel rounded-2xl overflow-hidden border border-white/10">
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm text-gray-300">
            <thead class="text-xs uppercase bg-white/5 border-b border-white/10 text-gray-400 font-semibold">
              <tr>
                <th class="px-6 py-4">Member</th>
                <th class="px-6 py-4">Role / Department</th>
                <th class="px-6 py-4">Location</th>
                <th class="px-6 py-4">University</th>
                <th class="px-6 py-4 text-center">Favorite</th>
                <th class="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5">
              ${this.filteredMembers.map(member => {
                const isFav = this.favorites.includes(member.id);
                return `
                  <tr class="hover:bg-white/5 transition-colors group cursor-pointer" data-member-id="${member.id}">
                    <td class="px-6 py-4 flex items-center gap-3">
                      <img src="${member.imageUrl}" alt="${member.name}" class="w-10 h-10 rounded-full object-cover border border-white/20" />
                      <div>
                        <p class="font-bold text-white group-hover:text-cyan-300 transition-colors">${member.name}</p>
                        <p class="text-xs text-gray-400">${member.email}</p>
                      </div>
                    </td>
                    <td class="px-6 py-4">
                      <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${member.badgeColor} text-white">
                        ${member.designation}
                      </span>
                    </td>
                    <td class="px-6 py-4">
                      <span class="flex items-center gap-1.5">
                        <span>${member.countryFlag}</span>
                        <span>${member.city ? `${member.city}, ` : ''}${member.country}</span>
                      </span>
                    </td>
                    <td class="px-6 py-4 text-xs text-gray-400">${member.university || '—'}</td>
                    <td class="px-6 py-4 text-center">
                      <button class="favorite-btn p-1.5 rounded-lg hover:bg-white/10 text-gray-400" data-fav-id="${member.id}">
                        <i data-lucide="heart" class="w-4 h-4 ${isFav ? 'fill-pink-500 text-pink-500' : ''}"></i>
                      </button>
                    </td>
                    <td class="px-6 py-4 text-right">
                      <button 
                        class="view-profile-btn px-3 py-1.5 rounded-lg bg-blue-500/20 hover:bg-blue-500 text-cyan-300 hover:text-white text-xs font-medium transition-colors"
                        data-member-id="${member.id}"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    this.attachCardEvents(container);
  }

  attachCardEvents(container) {
    // 1. View Profile / Modal Trigger
    container.querySelectorAll('.view-profile-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-member-id');
        this.openModal(id);
      });
    });

    // Row click in list
    container.querySelectorAll('tr[data-member-id]').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('button') || e.target.closest('a')) return;
        const id = row.getAttribute('data-member-id');
        this.openModal(id);
      });
    });

    // 2. Favorite Buttons
    container.querySelectorAll('.favorite-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = btn.getAttribute('data-fav-id');
        this.toggleFavorite(id, e);
      });
    });

    // 3. Copy Email Buttons
    container.querySelectorAll('.copy-email-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const email = btn.getAttribute('data-email');
        this.copyToClipboard(email, "Email copied to clipboard! 📋");
      });
    });
  }

  openModal(memberId) {
    const member = this.members.find(m => m.id === memberId);
    if (!member) return;

    sounds.playOpenModal();
    this.activeModalMember = member;

    const modal = document.getElementById('profile-modal');
    const modalContent = document.getElementById('modal-card-content');
    if (!modal || !modalContent) return;

    const isFav = this.favorites.includes(member.id);

    modalContent.innerHTML = `
      <div class="relative p-6 sm:p-8">
        <!-- Close Button -->
        <button id="modal-close-btn" class="absolute top-6 right-6 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition-colors z-20">
          <i data-lucide="x" class="w-5 h-5"></i>
        </button>

        <!-- Top Profile Banner -->
        <div class="flex flex-col sm:flex-row items-center sm:items-start gap-6 pb-6 border-b border-white/10">
          <div class="relative">
            <div class="avatar-ring p-1">
              <img 
                src="${member.imageUrl}" 
                alt="${member.name}" 
                class="w-32 h-32 sm:w-36 sm:h-36 object-cover rounded-full bg-gray-900 border-4 border-gray-950 shadow-2xl"
              />
            </div>
            <span class="absolute bottom-2 right-2 w-5 h-5 rounded-full bg-emerald-500 border-2 border-gray-900 status-beacon"></span>
          </div>

          <div class="text-center sm:text-left flex-1">
            <div class="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-2">
              <span class="text-xs uppercase tracking-wider font-semibold px-3 py-1 rounded-full bg-gradient-to-r ${member.badgeColor} text-white">
                ${member.tag}
              </span>
              <button 
                id="modal-fav-toggle" 
                class="px-3 py-1 rounded-full bg-white/10 hover:bg-pink-500/20 text-xs text-gray-300 hover:text-pink-400 flex items-center gap-1.5 transition-colors"
                data-fav-id="${member.id}"
              >
                <i data-lucide="heart" class="w-3.5 h-3.5 ${isFav ? 'fill-pink-500 text-pink-500' : ''}"></i>
                <span>${isFav ? 'Favorited' : 'Favorite'}</span>
              </button>
            </div>

            <h2 class="text-2xl sm:text-3xl font-extrabold text-white flex items-center justify-center sm:justify-start gap-2">
              ${member.name}
              <span title="${member.country}">${member.countryFlag}</span>
            </h2>
            <p class="text-base font-medium text-amber-400 mt-1">${member.designation}</p>

            <div class="flex flex-wrap items-center justify-center sm:justify-start gap-4 mt-3 text-xs text-gray-400">
              <span class="flex items-center gap-1">
                <i data-lucide="map-pin" class="w-4 h-4 text-cyan-400"></i>
                ${member.city ? `${member.city}, ` : ''}${member.country}
              </span>
              <span class="flex items-center gap-1">
                <i data-lucide="mail" class="w-4 h-4 text-purple-400"></i>
                ${member.email}
              </span>
            </div>
          </div>
        </div>

        <!-- Bio & Quote -->
        <div class="py-6 space-y-4">
          <blockquote class="p-4 rounded-xl bg-blue-500/10 border-l-4 border-cyan-400 text-cyan-200 text-sm italic">
            "${member.quote}"
          </blockquote>

          <div>
            <h4 class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2 flex items-center gap-1.5">
              <i data-lucide="user-check" class="w-4 h-4 text-cyan-400"></i>
              Executive Overview
            </h4>
            <p class="text-sm text-gray-300 leading-relaxed">${member.bio}</p>
          </div>

          ${member.university ? `
            <div>
              <h4 class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2 flex items-center gap-1.5">
                <i data-lucide="graduation-cap" class="w-4 h-4 text-amber-400"></i>
                Education & Alma Mater
              </h4>
              <p class="text-sm text-gray-300">${member.university}</p>
            </div>
          ` : ''}

          <!-- Core Skills -->
          <div>
            <h4 class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2 flex items-center gap-1.5">
              <i data-lucide="award" class="w-4 h-4 text-pink-400"></i>
              Core Competencies & Skills
            </h4>
            <div class="flex flex-wrap gap-2">
              ${member.skills.map(skill => `
                <span class="text-xs px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-gray-200">${skill}</span>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Action Footer -->
        <div class="pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
          <div class="flex items-center gap-2">
            ${member.socialLinks.linkedin ? `
              <a 
                href="${member.socialLinks.linkedin}" 
                target="_blank" 
                class="px-4 py-2 rounded-xl bg-[#0A66C2]/20 hover:bg-[#0A66C2] text-cyan-300 hover:text-white border border-[#0A66C2]/40 text-xs font-semibold flex items-center gap-2 transition-all"
              >
                <i data-lucide="linkedin" class="w-4 h-4"></i>
                <span>LinkedIn</span>
              </a>
            ` : ''}

            ${member.socialLinks.instagram ? `
              <a 
                href="${member.socialLinks.instagram}" 
                target="_blank" 
                class="px-4 py-2 rounded-xl bg-pink-500/20 hover:bg-pink-600 text-pink-300 hover:text-white border border-pink-500/40 text-xs font-semibold flex items-center gap-2 transition-all"
              >
                <i data-lucide="instagram" class="w-4 h-4"></i>
                <span>Instagram</span>
              </a>
            ` : ''}

            <a 
              href="mailto:${member.email}"
              class="px-4 py-2 rounded-xl bg-purple-500/20 hover:bg-purple-600 text-purple-300 hover:text-white border border-purple-500/40 text-xs font-semibold flex items-center gap-2 transition-all"
            >
              <i data-lucide="send" class="w-4 h-4"></i>
              <span>Send Email</span>
            </a>
          </div>

          <div class="flex items-center gap-2">
            <button 
              id="download-vcard-btn"
              class="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-2 transition-all"
              data-member-id="${member.id}"
            >
              <i data-lucide="contact-2" class="w-4 h-4 text-amber-400"></i>
              <span>Save vCard</span>
            </button>
          </div>
        </div>

      </div>
    `;

    modal.classList.remove('hidden');
    setTimeout(() => {
      modal.classList.add('modal-active');
    }, 10);

    // Modal internal listeners
    const closeBtn = document.getElementById('modal-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closeModal());
    }

    const favToggle = document.getElementById('modal-fav-toggle');
    if (favToggle) {
      favToggle.addEventListener('click', (e) => {
        this.toggleFavorite(member.id, e);
        this.openModal(member.id); // Refresh modal view
      });
    }

    const vCardBtn = document.getElementById('download-vcard-btn');
    if (vCardBtn) {
      vCardBtn.addEventListener('click', () => this.downloadVCard(member));
    }

    if (window.lucide) window.lucide.createIcons();
  }

  closeModal() {
    const modal = document.getElementById('profile-modal');
    if (!modal) return;
    modal.classList.remove('modal-active');
    setTimeout(() => {
      modal.classList.add('hidden');
      this.activeModalMember = null;
    }, 300);
  }

  downloadVCard(member) {
    sounds.playSuccess();
    const vCardData = [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `FN:${member.name}`,
      `N:${member.name.split(' ').reverse().join(';')};;;`,
      `ORG:Castpotro`,
      `TITLE:${member.designation}`,
      `EMAIL;TYPE=INTERNET,WORK:${member.email}`,
      `ADR;TYPE=WORK:;;;${member.city || ''};;${member.country}`,
      `NOTE:${member.bio}`,
      member.socialLinks.linkedin ? `URL;TYPE=LinkedIn:${member.socialLinks.linkedin}` : '',
      'END:VCARD'
    ].filter(Boolean).join('\n');

    const blob = new Blob([vCardData], { type: 'text/vcard;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${member.name.replace(/\s+/g, '_')}_Castpotro.vcf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    this.showToast(`Downloaded vCard for ${member.name}`, "success");
  }

  exportData(format) {
    sounds.playSuccess();
    if (format === 'json') {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(this.members, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", "castpotro_team.json");
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      this.showToast("Exported team JSON successfully!", "success");
    } else if (format === 'csv') {
      const headers = ["ID", "Name", "Designation", "City", "Country", "University", "Email", "LinkedIn", "Instagram"];
      const rows = this.members.map(m => [
        `"${m.id}"`,
        `"${m.name}"`,
        `"${m.designation}"`,
        `"${m.city || ''}"`,
        `"${m.country}"`,
        `"${m.university || ''}"`,
        `"${m.email}"`,
        `"${m.socialLinks.linkedin || ''}"`,
        `"${m.socialLinks.instagram || ''}"`
      ]);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "castpotro_team.csv");
      document.body.appendChild(link);
      link.click();
      link.remove();
      this.showToast("Exported team CSV successfully!", "success");
    }
  }

  copyToClipboard(text, successMessage) {
    sounds.playSuccess();
    navigator.clipboard.writeText(text).then(() => {
      this.showToast(successMessage, "success");
      this.triggerConfetti();
    }).catch(() => {
      this.showToast("Copied to clipboard!", "success");
    });
  }

  showToast(message, type = "info") {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    const isSuccess = type === "success";

    toast.className = `toast flex items-center gap-3 px-4 py-3 rounded-xl glass-panel border ${isSuccess ? 'border-emerald-500/40 text-emerald-300' : 'border-blue-500/40 text-blue-300'} shadow-2xl`;
    toast.innerHTML = `
      <i data-lucide="${isSuccess ? 'check-circle-2' : 'info'}" class="w-5 h-5 shrink-0"></i>
      <span class="text-sm font-medium text-white">${message}</span>
    `;

    container.appendChild(toast);
    if (window.lucide) window.lucide.createIcons();

    setTimeout(() => toast.classList.add('show'), 10);

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 400);
    }, 3200);
  }

  triggerConfetti() {
    if (window.confetti) {
      window.confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#649BE1', '#DE5491', '#F59E0B', '#14B8A6']
      });
    }
  }

  triggerSparkles(targetElement) {
    if (window.confetti && targetElement) {
      const rect = targetElement.getBoundingClientRect();
      window.confetti({
        particleCount: 25,
        spread: 40,
        origin: {
          x: (rect.left + rect.width / 2) / window.innerWidth,
          y: (rect.top + rect.height / 2) / window.innerHeight
        },
        colors: ['#DE5491', '#F472B6', '#FFFFFF']
      });
    }
  }

  setupEventListeners() {
    // 1. Search Input
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value;
        this.filterMembers();
      });
    }

    // 2. View Switcher Buttons
    const viewButtons = document.querySelectorAll('.view-btn');
    viewButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        sounds.playClick();
        const view = btn.getAttribute('data-view');
        this.currentView = view;
        viewButtons.forEach(b => {
          b.classList.remove('bg-white/20', 'text-white', 'border-cyan-400');
          b.classList.add('text-gray-400', 'border-transparent');
        });
        btn.classList.add('bg-white/20', 'text-white', 'border-cyan-400');
        btn.classList.remove('text-gray-400', 'border-transparent');
        this.render();
      });
    });

    // 3. Audio Mute / Unmute Toggle
    const soundToggleBtn = document.getElementById('sound-toggle-btn');
    if (soundToggleBtn) {
      soundToggleBtn.addEventListener('click', () => {
        const isEnabled = sounds.toggle();
        const icon = soundToggleBtn.querySelector('i');
        if (icon) {
          icon.setAttribute('data-lucide', isEnabled ? 'volume-2' : 'volume-x');
          if (window.lucide) window.lucide.createIcons();
        }
        this.showToast(isEnabled ? "Sound FX Enabled 🔊" : "Sound FX Muted 🔇", "info");
      });
    }

    // 4. Export Buttons
    const exportJsonBtn = document.getElementById('export-json-btn');
    if (exportJsonBtn) {
      exportJsonBtn.addEventListener('click', () => this.exportData('json'));
    }

    const exportCsvBtn = document.getElementById('export-csv-btn');
    if (exportCsvBtn) {
      exportCsvBtn.addEventListener('click', () => this.exportData('csv'));
    }

    // 5. Modal Backdrop click to close
    const modalBackdrop = document.getElementById('modal-backdrop');
    if (modalBackdrop) {
      modalBackdrop.addEventListener('click', () => this.closeModal());
    }

    // 6. Keyboard Shortcuts
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.closeModal();
      } else if (e.key === '/' && document.activeElement !== searchInput) {
        e.preventDefault();
        if (searchInput) searchInput.focus();
      } else if (this.currentView === 'coverflow') {
        if (e.key === 'ArrowLeft') {
          sounds.playClick();
          this.coverflowIndex = (this.coverflowIndex - 1 + this.filteredMembers.length) % this.filteredMembers.length;
          this.render();
        } else if (e.key === 'ArrowRight') {
          sounds.playClick();
          this.coverflowIndex = (this.coverflowIndex + 1) % this.filteredMembers.length;
          this.render();
        }
      }
    });
  }
}

// Instantiate on DOM load
document.addEventListener('DOMContentLoaded', () => {
  window.teamApp = new TeamApp();
});
