/**
 * Castpotro Team Portfolio Data
 */
export const TEAM_MEMBERS = [
  {
    id: "ibrahim-shanto",
    name: "Ibrahim Shanto",
    designation: "Chief Executive Officer (CEO)",
    category: "leadership",
    tag: "Leadership",
    city: "Dhaka",
    country: "Bangladesh",
    countryCode: "bd",
    countryFlag: "🇧🇩",
    university: "United International University (Graduated)",
    email: "ishanto.per@gmail.com",
    imageUrl: "images/Shanto.jpg",
    bio: "Strategic and visionary executive driving Castpotro's global mission, high-performance cross-border collaboration, technological ventures, and executive alignment.",
    quote: "Building bridges through technology, community, and purpose-driven execution.",
    skills: ["Executive Leadership", "Strategic Vision", "Product Management", "Team Building", "Operations"],
    badgeColor: "from-amber-500 to-orange-500",
    glowColor: "rgba(245, 158, 11, 0.35)",
    socialLinks: {
      linkedin: "https://www.linkedin.com/in/ibrahim-shanto/",
      instagram: null
    }
  },
  {
    id: "ahsan-farabi",
    name: "Ahsan Farabi",
    designation: "Founder",
    category: "leadership",
    tag: "Leadership",
    city: "Dhaka",
    country: "Bangladesh",
    countryCode: "bd",
    countryFlag: "🇧🇩",
    university: "United International University (Graduated)",
    email: "fuad000219@gmail.com",
    imageUrl: "images/Farabi.jpg",
    bio: "Pioneer and creative architect driving the foundational mission, ethos, and continuous innovation pipeline of Castpotro.",
    quote: "Igniting ideas that transform into tangible, impactful solutions for all.",
    skills: ["Foundational Strategy", "Venture Building", "System Architecture", "Creative Direction"],
    badgeColor: "from-blue-500 to-cyan-500",
    glowColor: "rgba(99, 102, 241, 0.35)",
    socialLinks: {
      linkedin: "https://www.linkedin.com/in/md-abdul-ahad-minhaz-5891b7430?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      instagram: "https://www.instagram.com/min.haze?igsi=MTM2MjZhMngxMHhuOA=="
    }
  },
  {
    id: "anastasiia-susol",
    name: "Anastasiia Susol (Mykolaivna)",
    designation: "Chief Operating Officer (COO)",
    category: "operations",
    tag: "Operations",
    city: "Lviv",
    country: "Ukraine",
    countryCode: "ua",
    countryFlag: "🇺🇦",
    university: "Lviv Polytechnic National University",
    email: "nnastysiikk@gmail.com",
    imageUrl: "images/Anastasia.PNG",
    bio: "Operational strategist driving smooth execution, global synchronization, team productivity, and systematic scalability across international borders.",
    quote: "Efficiency and empathy are the twin pillars of sustainable growth.",
    skills: ["Global Operations", "Process Optimization", "Cross-Functional Leadership", "Resource Management"],
    badgeColor: "from-teal-400 to-emerald-500",
    glowColor: "rgba(20, 184, 166, 0.35)",
    socialLinks: {
      linkedin: "https://www.linkedin.com/in/anastasiia-susol-398809361?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app",
      instagram: "https://www.instagram.com/nastysiik/"
    }
  },
  {
    id: "batzhargal-liza",
    name: "Batzhargal Liza",
    designation: "Head of Human Resources (HR)",
    category: "hr",
    tag: "Human Resources",
    city: "Karaganda",
    country: "Kazakhstan",
    countryCode: "kz",
    countryFlag: "🇰🇿",
    university: "L.N. Gumilyov Eurasian National University",
    email: "batzhargal31@gmail.com",
    imageUrl: "images/Liza.jpg",
    bio: "Dedicated people champion cultivating a thriving global culture, talent excellence, diversity, and compassionate human resources practices.",
    quote: "Empowering every individual to discover their greatest potential.",
    skills: ["Talent Acquisition", "People Operations", "Global Culture", "Conflict Resolution", "Workplace Well-being"],
    badgeColor: "from-purple-500 to-pink-500",
    glowColor: "rgba(236, 72, 153, 0.35)",
    socialLinks: {
      linkedin: "https://www.linkedin.com/in/liza-batzhargal-5186612bb?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      instagram: "https://www.instagram.com/_reptiiliian_?igsi=NnM5YzFtbXBqMmE3"
    }
  },
  {
    id: "asma-ul-hosna",
    name: "Asma Ul Hosna",
    designation: "Head of Meetings and Events (M&E)",
    category: "events",
    tag: "Events & Community",
    city: "Dhaka",
    country: "Bangladesh",
    countryCode: "bd",
    countryFlag: "🇧🇩",
    university: "United International University",
    email: "asmaulhosna801@gmail.com",
    imageUrl: "images/Asma Ul Hosna.jpg",
    bio: "Event orchestrator curating high-energy summits, international meetups, engaging townhalls, and memorable community experiences.",
    quote: "Creating spaces where ideas collide and meaningful connections flourish.",
    skills: ["Event Management", "Summit Organization", "Public Relations", "Community Engagement", "Logistics"],
    badgeColor: "from-rose-500 to-pink-600",
    glowColor: "rgba(244, 63, 94, 0.35)",
    socialLinks: {
      linkedin: "https://www.linkedin.com/in/asma-ul-hosna-0ab240298?utm_source=share_via&utm_content=profile&utm_medium=member_ios",
      instagram: "https://www.instagram.com/asma_hosna1_?igsi=MTc2N2w2dmtpdzFzdw%3D%3D&utm_source=qr"
    }
  },
  {
    id: "asma-seddiqi",
    name: "Asma Seddiqi",
    designation: "Head of Marketing Department",
    category: "marketing",
    tag: "Marketing",
    city: "Kabul",
    country: "Afghanistan",
    countryCode: "af",
    countryFlag: "🇦🇫",
    university: "International Business & Comms",
    email: "elsaseddiqi4@gmail.com",
    imageUrl: "images/Asma Seddique.jpg",
    bio: "Dynamic brand strategist leading global marketing initiatives, brand presence, digital reach, and compelling visual storytelling across cultures.",
    quote: "Telling stories that resonate globally and inspire positive action.",
    skills: ["Brand Strategy", "Digital Marketing", "Social Media Campaigns", "Content Creation", "Audience Growth"],
    badgeColor: "from-fuchsia-500 to-indigo-500",
    glowColor: "rgba(168, 85, 247, 0.35)",
    socialLinks: {
      linkedin: null,
      instagram: "https://www.instagram.com/seddiqiasma/"
    }
  },
  {
    id: "md-abdul-ahad-minhaz",
    name: "Md Abdul Ahad Minhaz",
    designation: "Manager",
    category: "management",
    tag: "Management",
    city: "Dhaka",
    country: "Bangladesh",
    countryCode: "bd",
    countryFlag: "🇧🇩",
    university: "United International University",
    email: "fuad000219@gmail.com",
    imageUrl: "images/Minhaz.jpg",
    bio: "Hands-on manager orchestrating project lifecycles, team alignment, productivity metrics, and operational synergy.",
    quote: "Consistent momentum and thoughtful collaboration drive true results.",
    skills: ["Project Management", "Team Coordination", "Strategic Planning", "Workflow Automation"],
    badgeColor: "from-cyan-500 to-blue-600",
    glowColor: "rgba(6, 182, 212, 0.35)",
    socialLinks: {
      linkedin: "https://www.linkedin.com/in/md-abdul-ahad-minhaz-5891b7430?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      instagram: "https://www.instagram.com/min.haze?igsi=MTM2MjZhMngxMHhuOA=="
    }
  },
  {
    id: "duru-cilingiroglu",
    name: "Duru Çilingiroğlu",
    designation: "Human Resource Intern",
    category: "hr",
    tag: "Interns / HR",
    city: "Bursa",
    country: "Türkiye",
    countryCode: "tr",
    countryFlag: "🇹🇷",
    university: "Kaşgarlı Mahmud Anatolian High School",
    email: "durucilingir2009@hotmail.com",
    imageUrl: "images/Duru.jpg",
    bio: "Enthusiastic and agile HR intern supporting global candidate sourcing, onboarding processes, and community communication.",
    quote: "Learning relentlessly and bringing youthful energy to every challenge.",
    skills: ["Talent Sourcing", "Team Communication", "Onboarding Support", "International Relations"],
    badgeColor: "from-yellow-400 to-amber-500",
    glowColor: "rgba(251, 191, 36, 0.35)",
    socialLinks: {
      linkedin: "https://www.linkedin.com/in/duruçilingiroğlu?utm_source=share_via&utm_content=profile&utm_medium=member_ios",
      instagram: "https://www.instagram.com/dduruclngr?igsi=aXZzNnpkc3VpYnR2&utm_source=qr"
    }
  }
];

export const CATEGORIES = [
  { id: "all", label: "All Members", icon: "users" },
  { id: "leadership", label: "Leadership", icon: "shield-check" },
  { id: "operations", label: "Operations", icon: "cpu" },
  { id: "marketing", label: "Marketing", icon: "sparkles" },
  { id: "hr", label: "Human Resources", icon: "heart-handshake" },
  { id: "events", label: "Events & M&E", icon: "calendar" },
  { id: "management", label: "Management", icon: "briefcase" }
];
